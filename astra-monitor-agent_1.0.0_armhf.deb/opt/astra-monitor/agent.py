#!/usr/bin/python3
import os, sys, time, json, hashlib, subprocess, logging
import requests
import yaml
from datetime import datetime

CONFIG_PATH = '/etc/astra-monitor/config.yaml'
LOG_FILE = '/var/log/astra-monitor.log'
HEARTBEAT_INTERVAL = 300  # 5 минут
INDEX_INTERVAL = 3600     # 1 час

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout)
    ]
)
log = logging.getLogger('afm-agent')

def load_config():
    with open(CONFIG_PATH, 'r') as f:
        cfg = yaml.safe_load(f)
    return cfg

def recoll_index():
    """Обновление индекса Recoll для /home"""
    try:
        subprocess.run(['recollindex'], check=True, timeout=600)
        log.info("Recoll index updated.")
    except subprocess.CalledProcessError as e:
        log.error(f"recollindex error: {e}")
    except subprocess.TimeoutExpired:
        log.error("recollindex timed out.")

def get_indexed_files():
    """Получить список файлов из Recoll (упрощённо через recoll -t)"""
    try:
        output = subprocess.check_output(['recoll', '-t', '-q', '*'], universal_newlines=True)
    except:
        return []
    files = []
    for line in output.splitlines():
        if line.startswith('file://'):
            path = line[7:]
            files.append(path)
    return files

def send_files(server_url, token, new_files):
    """Отправить метаданные файлов на сервер"""
    headers = {'Authorization': f'Token {token}', 'Content-Type': 'application/json'}
    batch = []
    for fpath in new_files:
        try:
            stat = os.stat(fpath)
        except:
            continue
        # извлечение текста (заглушка)
        content = ""
        try:
            with open(fpath, 'r', errors='ignore') as f:
                content = f.read(2000)
        except:
            pass
        batch.append({
            'file_path': fpath,
            'file_name': os.path.basename(fpath),
            'file_size': stat.st_size,
            'file_mtime': datetime.fromtimestamp(stat.st_mtime).isoformat(),
            'content_text': content
        })
        if len(batch) >= 50:
            resp = requests.post(f'{server_url}/api/agent/files/', json={'files': batch}, headers=headers)
            if resp.status_code == 201:
                log.info(f"Sent {len(batch)} files.")
            else:
                log.error(f"Upload error: {resp.status_code}")
            batch = []
    if batch:
        resp = requests.post(f'{server_url}/api/agent/files/', json={'files': batch}, headers=headers)
        if resp.status_code == 201:
            log.info(f"Sent {len(batch)} files.")

def check_triggers(content, triggers):
    """Проверить текст на триггерные слова и отправить инцидент"""
    for word in triggers:
        if word.lower() in content.lower():
            return word
    return None

def main():
    cfg = load_config()
    server_url = cfg['server_url']
    token = cfg['token']
    last_index_time = 0
    known_files = set()
    triggers = []

    while True:
        try:
            # Heartbeat
            resp = requests.post(f'{server_url}/api/agent/heartbeat/',
                                 headers={'Authorization': f'Token {token}'})
            if resp.status_code == 200:
                data = resp.json()
                triggers = data.get('triggers', [])
                log.info("Heartbeat OK.")
            else:
                log.error(f"Heartbeat failed: {resp.status_code}")

            # Индексация раз в час
            now = time.time()
            if now - last_index_time > INDEX_INTERVAL:
                recoll_index()
                last_index_time = now
                current_files = set(get_indexed_files())
                new_files = current_files - known_files
                if new_files:
                    send_files(server_url, token, list(new_files))
                known_files = current_files

                # Проверка триггеров для всех файлов (можно оптимизировать)
                # Для простоты проверим только новые файлы
                for fpath in new_files:
                    try:
                        with open(fpath, 'r', errors='ignore') as f:
                            content = f.read()
                        trig = check_triggers(content, triggers)
                        if trig:
                            incident_data = {
                                'file_path': fpath,
                                'file_name': os.path.basename(fpath),
                                'file_owner': 'unknown',
                                'context': content[:200],
                                'trigger_word': trig
                            }
                            requests.post(f'{server_url}/api/agent/incident/',
                                         json=incident_data,
                                         headers={'Authorization': f'Token {token}'})
                            log.info(f"Incident reported: {trig} in {fpath}")
                    except:
                        pass
        except Exception as e:
            log.error(f"Main loop error: {e}")

        time.sleep(HEARTBEAT_INTERVAL)

if __name__ == '__main__':
    main()
